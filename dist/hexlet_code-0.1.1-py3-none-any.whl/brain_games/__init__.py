"""This is an example script."""
from brain_games.scripts import engine  # noqa: F401
