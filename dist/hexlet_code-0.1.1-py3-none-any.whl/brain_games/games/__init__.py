"""This is an example script."""
from brain_games.games import calc, even  # noqa: F401
