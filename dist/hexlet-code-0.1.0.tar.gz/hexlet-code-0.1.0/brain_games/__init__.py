"""This is an example script."""
